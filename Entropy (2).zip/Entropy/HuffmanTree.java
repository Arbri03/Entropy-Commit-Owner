import java.util.*;

/**
 * This class constructs a Huffman tree from a frequency map and computes code lengths.
 * It is used to analyze compressibility based on character or token frequencies.
 */
public class HuffmanTree {

    /**
     * Internal class representing a node in the Huffman tree.
     */
    public static class HuffmanNode implements Comparable<HuffmanNode> {
        String symbol;
        int freq;
        HuffmanNode left, right;

        public HuffmanNode(String symbol, int freq) {
            this.symbol = symbol;
            this.freq = freq;
        }

        /**
         * @return True if the node is a leaf (i.e., a real symbol), false otherwise
         */
        public boolean isLeaf() {
            return left == null && right == null;
        }

        @Override
        public int compareTo(HuffmanNode other) {
            return Integer.compare(this.freq, other.freq);
        }
    }

    /**
     * Builds a Huffman tree from the given frequency map.
     *
     * @param freqMap A map of symbols (e.g. n-grams) and their frequencies
     * @return The root node of the constructed Huffman tree
     */
    public static HuffmanNode build(Map<String, Integer> freqMap) {
        PriorityQueue<HuffmanNode> pq = new PriorityQueue<>();
        for (Map.Entry<String, Integer> entry : freqMap.entrySet()) {
            pq.add(new HuffmanNode(entry.getKey(), entry.getValue()));
        }

        while (pq.size() > 1) {
            HuffmanNode n1 = pq.poll();
            HuffmanNode n2 = pq.poll();
            HuffmanNode merged = new HuffmanNode(null, n1.freq + n2.freq);
            merged.left = n1;
            merged.right = n2;
            pq.add(merged);
        }

        return pq.poll();  // root of the Huffman tree
    }

    /**
     * Recursively computes the Huffman code length for each symbol in the tree.
     *
     * @param node The current node (starts with root)
     * @param depth The depth in the tree (represents code length)
     * @param codeLengths A map to populate with symbol → code length entries
     */
    public static void computeCodeLengths(HuffmanNode node, int depth, Map<String, Integer> codeLengths) {
        if (node == null) return;
        if (node.isLeaf()) {
            codeLengths.put(node.symbol, depth);
        } else {
            computeCodeLengths(node.left, depth + 1, codeLengths);
            computeCodeLengths(node.right, depth + 1, codeLengths);
        }
    }
}
