import java.util.*;

/**
 * Represents an n-gram model built from a list of tokens.
 * Provides methods for computing entropy and comparing with Huffman encoding.
 */
public class NGramModel {
    private final Map<String, Integer> frequency;
    private final int totalTokens;

    /**
     * Builds the model from a list of n-gram tokens.
     *
     * @param ngrams List of n-gram strings extracted from text
     */
    public NGramModel(List<String> ngrams) {
        this.frequency = new HashMap<>();
        for (String token : ngrams) {
            frequency.put(token, frequency.getOrDefault(token, 0) + 1);
        }
        this.totalTokens = ngrams.size();
    }

    /**
     * @return The raw frequency map of n-gram tokens
     */
    public Map<String, Integer> getFrequency() {
        return frequency;
    }

    /**
     * @return The total number of tokens used in the model
     */
    public int getTotalTokens() {
        return totalTokens;
    }

    /**
     * Computes the Shannon entropy of the n-gram distribution.
     *
     * @return Entropy in bits, using base-2 logarithm
     */
    public double computeEntropy() {
        double entropy = 0.0;
        for (int count : frequency.values()) {
            double p = (double) count / totalTokens;
            entropy -= p * (Math.log(p) / Math.log(2));
        }
        return entropy;
    }

    /**
     * Computes the average code length if Huffman encoding were applied.
     *
     * @return Expected code length based on Huffman tree and token probabilities
     */
    public double averageHuffmanCodeLength() {
        HuffmanTree.HuffmanNode root = HuffmanTree.build(frequency);
        Map<String, Integer> codeLengths = new HashMap<>();
        HuffmanTree.computeCodeLengths(root, 0, codeLengths);

        double avgLength = 0.0;
        for (Map.Entry<String, Integer> entry : frequency.entrySet()) {
            double p = (double) entry.getValue() / totalTokens;
            avgLength += p * codeLengths.get(entry.getKey());
        }
        return avgLength;
    }

    /**
     * Returns the top-K most frequent n-gram tokens.
     *
     * @param k Number of top tokens to return
     * @return List of top-k tokens
     */
    public List<String> topK(int k) {
        return frequency.entrySet().stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .limit(Math.min(k, frequency.size()))
            .map(Map.Entry::getKey)
            .toList();
    }

    /**
     * Returns the bottom-K least frequent n-gram tokens.
     *
     * @param k Number of bottom tokens to return
     * @return List of bottom-k tokens
     */
    public List<String> bottomK(int k) {
        return frequency.entrySet().stream()
            .sorted(Map.Entry.comparingByValue())
            .limit(Math.min(k, frequency.size()))
            .map(Map.Entry::getKey)
            .toList();
    }
}
