import java.util.*;

/**
 * Classifies input text into one of several known languages using bigram models.
 */
public class LanguageClassifier {
    private final Map<String, BigramLanguageModel> models;

    /**
     * Initializes an empty language classifier.
     */
    public LanguageClassifier() {
        models = new HashMap<>();
    }

    /**
     * Adds a new language and its corresponding bigram model.
     *
     * @param name The name of the language (e.g., \"Albanian\")
     * @param model The bigram language model for that language
     */
    public void addLanguage(String name, BigramLanguageModel model) {
        models.put(name, model);
    }

    /**
     * Classifies a given sentence based on which language model scores it highest.
     *
     * @param sentence A sentence in an unknown language
     * @return The predicted language name with the highest score
     */
    public String classify(String sentence) {
        String bestLang = null;
        double bestScore = Double.NEGATIVE_INFINITY;

        for (Map.Entry<String, BigramLanguageModel> entry : models.entrySet()) {
            double score = entry.getValue().score(sentence);
            if (score > bestScore) {
                bestScore = score;
                bestLang = entry.getKey();
            }
        }

        return bestLang;
    }
}
