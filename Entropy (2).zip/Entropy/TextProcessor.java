import java.util.*;

/**
 * Utility class for preprocessing text and extracting n-gram sequences.
 * It filters out non-Albanian letters and generates character-based n-grams.
 */
public class TextProcessor {
    private static final Set<Character> ALBANIAN_ALPHABET = Set.of(
        'a','b','c','ç','d','e','ë','f','g','h','i','j','k','l','m','n','o',
        'p','q','r','s','t','u','v','x','y','z'
    );

    /**
     * Cleans a given text by removing non-Albanian characters and converting to lowercase.
     * Only letters in the defined Albanian alphabet are preserved.
     *
     * @param text The raw input text to be cleaned
     * @return A cleaned version of the text containing only lowercase Albanian letters
     */
    public static String clean(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toLowerCase().toCharArray()) {
            if (ALBANIAN_ALPHABET.contains(c)) {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /**
     * Extracts all overlapping character n-grams of a given size from the input text.
     *
     * @param text The input string (usually pre-cleaned)
     * @param n The size of each n-gram to extract
     * @return A list of n-gram strings, or an empty list if n is invalid or too large
     */
    public static List<String> extractNGrams(String text, int n) {
        List<String> ngrams = new ArrayList<>();
        if (n <= 0 || text.length() < n) return ngrams;
        for (int i = 0; i <= text.length() - n; i++) {
            ngrams.add(text.substring(i, i + n));
        }
        return ngrams;
    }
}
