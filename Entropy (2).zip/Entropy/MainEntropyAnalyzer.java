import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Entry point for analyzing entropy and Huffman coding of multiple text files.
 * Automatically reads all .txt files from the ./data/ folder.
 * Performs entropy and Huffman analysis for n = 0 to 10.
 * Also includes optional bigram language classification (bonus).
 */
public class MainEntropyAnalyzer {

    public static void main(String[] args) throws IOException {
        File dataFolder = new File("data");
        if (!dataFolder.exists() || !dataFolder.isDirectory()) {
            System.err.println("Missing 'data' folder. Please create it and add your text files.");
            return;
        }

        File[] textFiles = dataFolder.listFiles((dir, name) -> name.endsWith(".txt"));
        if (textFiles == null || textFiles.length < 2) {
            System.err.println("Please place at least two .txt files in the 'data' folder.");
            return;
        }

        List<String> cleanedTexts = new ArrayList<>();
        for (File file : textFiles) {
            System.out.println("\nAnalyzing file: " + file.getName());
            String rawText = Files.readString(file.toPath());
            String cleanedText = TextProcessor.clean(rawText);
            cleanedTexts.add(cleanedText);

            analyzeText(cleanedText);
        }

        // BONUS: Language classification using first two files (e.g., Albanian and English)
        if (cleanedTexts.size() >= 2) {
            runLanguageClassifier(cleanedTexts.get(0), cleanedTexts.get(1),
                    textFiles[0].getName(), textFiles[1].getName());
        }
    }

    /**
     * Runs entropy and Huffman analysis for n = 0 to 10.
     */
    private static void analyzeText(String text) {
        for (int n = 0; n <= 10; n++) {
            List<String> ngrams;
            if (n == 0) {
                Set<Character> alphabet = new HashSet<>();
                for (char c : text.toCharArray()) {
                    alphabet.add(c);
                }
                double p = 1.0 / alphabet.size();
                double entropy = Math.log(alphabet.size()) / Math.log(2);
                System.out.printf("n = %2d | Entropy: %.4f (uniform over %d symbols)\n", n, entropy, alphabet.size());
                continue;
            }

            ngrams = TextProcessor.extractNGrams(text, n);
            if (ngrams.isEmpty()) continue;

            NGramModel model = new NGramModel(ngrams);
            double entropy = model.computeEntropy();
            double avgLength = model.averageHuffmanCodeLength();
            List<String> top5 = model.topK(5);
            List<String> bottom5 = model.bottomK(5);

            System.out.printf("n = %2d | Entropy: %.4f | Huffman Avg Len: %.4f | Tokens: %d\n",
                    n, entropy, avgLength, model.getTotalTokens());
            System.out.println("   Top 5:    " + top5);
            System.out.println("   Bottom 5: " + bottom5);
        }
    }

    /**
     * Demonstrates language classification using bigram models.
     */
    private static void runLanguageClassifier(String cleanedText1, String cleanedText2,
                                              String name1, String name2) {
        System.out.println("\n--- Language Classifier (Bonus) ---");

        List<String> bigrams1 = TextProcessor.extractNGrams(cleanedText1, 2);
        List<String> bigrams2 = TextProcessor.extractNGrams(cleanedText2, 2);

        NGramModel model1 = new NGramModel(bigrams1);
        NGramModel model2 = new NGramModel(bigrams2);

        BigramLanguageModel lang1 = new BigramLanguageModel(model1.getFrequency(), model1.getTotalTokens());
        BigramLanguageModel lang2 = new BigramLanguageModel(model2.getFrequency(), model2.getTotalTokens());

        LanguageClassifier classifier = new LanguageClassifier();
        classifier.addLanguage(name1, lang1);
        classifier.addLanguage(name2, lang2);

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("\nEnter a sentence to classify (or 'exit'): ");
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("exit")) break;

            String result = classifier.classify(input);
            System.out.println("Predicted Language: " + result);
        }
    }
}
