import java.util.*;

/**
 * A language model based on bigram frequencies.
 * Scores input sentences using log-likelihood under the trained distribution.
 */
public class BigramLanguageModel {
    private final Map<String, Integer> freq;
    private final int totalTokens;

    /**
     * Constructs the model using known bigram frequencies and token count.
     *
     * @param freq Map of bigram → count
     * @param totalTokens Total number of bigrams observed
     */
    public BigramLanguageModel(Map<String, Integer> freq, int totalTokens) {
        this.freq = freq;
        this.totalTokens = totalTokens;
    }

    /**
     * Scores a sentence using log-likelihood under the bigram model.
     * Unseen bigrams are smoothed using a small constant.
     *
     * @param sentence A raw sentence in an unknown language
     * @return Log-likelihood score (higher = better match)
     */
    public double score(String sentence) {
        String cleaned = TextProcessor.clean(sentence);
        List<String> bigrams = TextProcessor.extractNGrams(cleaned, 2);
        double logLikelihood = 0.0;
        double epsilon = 1e-6;  // Smoothing constant for unseen bigrams

        for (String b : bigrams) {
            int count = freq.getOrDefault(b, 0);
            double p = count > 0 ? (double) count / totalTokens : epsilon;
            logLikelihood += Math.log(p) / Math.log(2);
        }

        return logLikelihood;
    }
}
