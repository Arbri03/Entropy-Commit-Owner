import java.io.*;
import java.util.*;

/**
 * Main class for running the Commit Owners program (Part II).
 * 
 * Given a CSV file of employees and a weld string (concatenated ID sequence),
 * it outputs the sequence of employee IDs that most likely made the commits,
 * favoring the configuration with the most commits (shortest IDs used).
 *
 * Usage:
 *   java CommitOwnersProgram <employee_file> <weld_string>
 */
public class CommitOwnersProgram {
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java CommitOwnersProgram <employee_file> <weld_string>");
            return;
        }

        String employeeFile = args[0];
        String weld = args[1];

        // Read valid employee IDs from file
        Set<String> validIDs = InputProcessor.readEmployeeFile(employeeFile);

        // Decode the weld into most likely commit sequence
        List<String> bestDecomposition = CommitParser.maxCommits(weld, validIDs);

        // Output result: one ID per line
        for (String id : bestDecomposition) {
            System.out.println(id);
        }

        // Optional: Uncomment to print total number of valid decompositions
        // int totalWays = CommitParser.countDecompositions(weld, validIDs);
        // System.out.println("Total valid decompositions: " + totalWays);
    }
}
