import java.util.*;

/**
 * Provides logic to decode a weld string into the most likely commit sequence.
 * 
 * Uses dynamic programming to find the decomposition of the weld string
 * that results in the highest number of commits (shortest splits).
 * 
 * Also includes a method to count all valid decompositions (Bonus).
 */
class CommitParser {

    /**
     * Returns the optimal decomposition (most commits) of the weld string.
     *
     * @param weld The weld string of concatenated employee IDs
     * @param validIDs Set of valid employee ID strings
     * @return A list of IDs forming the optimal decomposition
     */
    public static List<String> maxCommits(String weld, Set<String> validIDs) {
        int n = weld.length();
        Result[] memo = new Result[n + 1];
        return dp(0, weld, validIDs, memo).path;
    }

    /**
     * Recursive DP helper to find the path with the maximum number of IDs.
     */
    private static Result dp(int i, String weld, Set<String> validIDs, Result[] memo) {
        int n = weld.length();
        if (i == n) return new Result(0, new ArrayList<>());
        if (memo[i] != null) return memo[i];

        int maxCommits = -1;
        List<String> bestPath = new ArrayList<>();

        for (int j = i + 1; j <= n; j++) {
            String token = weld.substring(i, j);
            if (validIDs.contains(token)) {
                Result sub = dp(j, weld, validIDs, memo);
                if (1 + sub.count > maxCommits) {
                    maxCommits = 1 + sub.count;
                    bestPath = new ArrayList<>();
                    bestPath.add(token);
                    bestPath.addAll(sub.path);
                }
            }
        }

        memo[i] = new Result(maxCommits, bestPath);
        return memo[i];
    }

    /**
     * BONUS: Counts all valid ways to split the weld string into valid employee IDs.
     *
     * @param weld The weld string
     * @param validIDs Set of known employee IDs
     * @return Total number of valid decompositions
     */
    public static int countDecompositions(String weld, Set<String> validIDs) {
        int n = weld.length();
        Integer[] memo = new Integer[n + 1];
        return count(0, weld, validIDs, memo);
    }

    /**
     * Recursive DP helper for counting valid decompositions.
     */
    private static int count(int i, String weld, Set<String> validIDs, Integer[] memo) {
        int n = weld.length();
        if (i == n) return 1;
        if (memo[i] != null) return memo[i];

        int total = 0;
        for (int j = i + 1; j <= n; j++) {
            String token = weld.substring(i, j);
            if (validIDs.contains(token)) {
                total += count(j, weld, validIDs, memo);
            }
        }

        memo[i] = total;
        return total;
    }

    /**
     * Helper class to store intermediate results in DP.
     */
    private static class Result {
        int count;              // number of commits
        List<String> path;      // list of matched IDs

        Result(int count, List<String> path) {
            this.count = count;
            this.path = path;
        }
    }
}
