import java.io.*;
import java.util.*;

/**
 * Utility class to handle input processing for the Commit Owners problem.
 */
class InputProcessor {

    /**
     * Reads a CSV employee file and extracts all valid employee IDs.
     *
     * @param filename The path to the employee file
     * @return A set of valid employee ID strings
     */
    public static Set<String> readEmployeeFile(String filename) {
        Set<String> validIDs = new HashSet<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] tokens = line.split(",");
                if (tokens.length > 0) {
                    validIDs.add(tokens[0].trim());
                }
            }

        } catch (IOException e) {
            System.err.println("Error reading employee file: " + e.getMessage());
        }

        return validIDs;
    }
}
